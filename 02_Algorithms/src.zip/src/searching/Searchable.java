package searching;

public interface Searchable<E> {
	
	int search(E value);
}

package sorting;

public interface Sortable<E> {
	
	void sort(E[] data);
}
